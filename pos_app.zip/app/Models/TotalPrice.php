<?php

namespace App\Models;

use Astrotomic\Translatable\Translatable;
use Illuminate\Database\Eloquent\Model;

class TotalPrice extends Model
{

   protected $table = 'total_price';
   protected $guarded = [];

}//end of model
